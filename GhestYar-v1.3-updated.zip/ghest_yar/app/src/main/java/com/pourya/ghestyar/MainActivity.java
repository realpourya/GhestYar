package com.pourya.ghestyar;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

public class MainActivity extends Activity {
    LinearLayout list, root;
    TextView summary;
    android.content.SharedPreferences sp;
    ArrayList<Installment> items = new ArrayList<>();

    final int BLUE = Color.rgb(21,101,192);
    final int BG = Color.rgb(244,247,251);
    final int TEXT = Color.rgb(23,32,51);
    final int SECONDARY = Color.rgb(101,112,132);
    final String PREF = "installments";

    String[] defaultNames = {"قسط بانک سپه","قسط دیجی‌کالا - اسنپ‌پی","اجاره خانه","قسط وام ۱۰۰ تومنی محمد","قسط مؤسسه ملل","بیمه ماشین","قسط بانک مهر","قسط بانک مهر","قسط بانک مهر","وام خانگی"};
    int[] defaultDays = {3,5,8,11,13,16,16,17,18,30};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sp = getSharedPreferences(PREF, 0);
        load();
        build();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        scheduleAll();
    }

    static class Installment {
        String id, name, amount;
        int day;
        Installment(String i, String n, String a, int d) { id=i; name=n; amount=a; day=d; }
    }

    String paidKey(Installment x) {
        int[] p = PersianDate.now();
        return "paid_" + x.id + "_" + p[0] + "_" + p[1];
    }

    void load() {
        items.clear();
        int count = sp.getInt("count", -1);
        if (count < 0) {
            for (int i=0; i<defaultNames.length; i++)
                items.add(new Installment(UUID.randomUUID().toString(), defaultNames[i], "", defaultDays[i]));
            saveData();
            return;
        }
        for (int i=0; i<count; i++) {
            String id = sp.getString("id_"+i, UUID.randomUUID().toString());
            String n = sp.getString("name_"+i, "");
            String a = sp.getString("amount_"+i, "");
            int d = sp.getInt("day_"+i, 1);
            items.add(new Installment(id,n,a,d));
        }
    }

    // IMPORTANT: Do not clear SharedPreferences here.
    // Payment flags are intentionally preserved when the list is edited.
    void saveData() {
        android.content.SharedPreferences.Editor e = sp.edit();
        e.putInt("count", items.size());
        for (int i=0; i<items.size(); i++) {
            Installment x=items.get(i);
            e.putString("id_"+i,x.id);
            e.putString("name_"+i,x.name);
            e.putString("amount_"+i,x.amount);
            e.putInt("day_"+i,x.day);
        }
        // Remove only stale installment slots; never remove paid_* keys.
        int oldCount = sp.getInt("count", items.size());
        for (int i=items.size(); i<oldCount; i++) {
            e.remove("id_"+i).remove("name_"+i).remove("amount_"+i).remove("day_"+i);
        }
        e.apply();
    }

    int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(16), dp(10), dp(16), dp(8));
        root.setBackgroundColor(BG);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        head.setPadding(0,0,0,dp(6));

        TextView menuBtn = t("☰", 27, BLUE);
        menuBtn.setGravity(Gravity.CENTER);
        menuBtn.setContentDescription("منوی برنامه");
        menuBtn.setBackground(round(Color.WHITE, dp(12)));
        menuBtn.setElevation(dp(1));
        menuBtn.setOnClickListener(v -> showMainMenu(menuBtn));

        TextView title = t("قسط‌یار", 24, BLUE);
        title.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        title.setPadding(0,0,dp(4),0);

        head.addView(menuBtn, new LinearLayout.LayoutParams(dp(48), dp(46)));
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, dp(46), 1);
        titleLp.setMargins(dp(8),0,0,0);
        head.addView(title, titleLp);
        root.addView(head);

        summary = t("", 13, SECONDARY);
        summary.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        root.addView(summary, new LinearLayout.LayoutParams(-1, dp(34)));

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
        render();
    }

    TextView t(String s, int size, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return v;
    }

    GradientDrawable round(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    String dayText(int d) {
        String[] w={"","اول","دوم","سوم","چهارم","پنجم","ششم","هفتم","هشتم","نهم","دهم","یازدهم","دوازدهم","سیزدهم","چهاردهم","پانزدهم","شانزدهم","هفدهم","هجدهم","نوزدهم","بیستم","بیست‌ویکم","بیست‌ودوم","بیست‌وسوم","بیست‌وچهارم","بیست‌وپنجم","بیست‌وششم","بیست‌وهفتم","بیست‌وهشتم","بیست‌ونهم","سی‌ام","سی‌ویکم"};
        return d>=1&&d<=31 ? w[d] : String.valueOf(d);
    }

    String fmtAmount(String a) {
        if (a == null || a.trim().isEmpty()) return "";
        String raw = a.replace(",", "").replace("٬", "").trim();
        try {
            long value = Long.parseLong(raw);
            DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance(Locale.US);
            DecimalFormat formatter = new DecimalFormat("#,##0", symbols);
            return "  •  " + formatter.format(value) + " تومان";
        } catch (Exception e) {
            return "  •  " + a.trim() + " تومان";
        }
    }

    void render() {
        Collections.sort(items,(a,b)->Integer.compare(a.day,b.day));
        list.removeAllViews();

        int[] p=PersianDate.now();
        int paid=0;
        for (Installment x:items) if (sp.getBoolean(paidKey(x),false)) paid++;
        summary.setText("ماه " + p[1] + " / " + p[0] + "   •   " + paid + " از " + items.size() + " قسط پرداخت شده");

        for (Installment x:items) {
            final Installment item=x;

            LinearLayout card=new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            card.setPadding(dp(8),dp(5),dp(6),dp(5));
            card.setBackground(round(Color.WHITE,dp(14)));
            card.setElevation(dp(1));

            CheckBox cb=new CheckBox(this);
            cb.setText("پرداخت شد");
            cb.setTextSize(11);
            cb.setTextColor(TEXT);
            cb.setButtonTintList(ColorStateList.valueOf(BLUE));
            cb.setGravity(Gravity.CENTER);
            cb.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            cb.setChecked(sp.getBoolean(paidKey(item),false));
            cb.setOnClickListener(v -> {
                sp.edit().putBoolean(paidKey(item), cb.isChecked()).apply();
                render();
            });

            LinearLayout textBox=new LinearLayout(this);
            textBox.setOrientation(LinearLayout.VERTICAL);
            textBox.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
            textBox.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

            TextView name=t(item.name,15,TEXT);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);

            TextView day=t("روز " + dayText(item.day) + fmtAmount(item.amount),12,SECONDARY);
            day.setSingleLine(true);
            day.setEllipsize(android.text.TextUtils.TruncateAt.END);

            textBox.addView(name,new LinearLayout.LayoutParams(-1,dp(29)));
            textBox.addView(day,new LinearLayout.LayoutParams(-1,dp(24)));

            card.addView(cb,new LinearLayout.LayoutParams(dp(92),dp(56)));
            card.addView(textBox,new LinearLayout.LayoutParams(0,dp(56),1));

            card.setOnClickListener(v->showEditor(items.indexOf(item)));
            card.setOnLongClickListener(v->{confirmDelete(item);return true;});

            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(68));
            cp.setMargins(0,0,0,dp(6));
            list.addView(card,cp);
        }

        if(items.isEmpty()) {
            TextView e=t("هنوز قسطی ثبت نشده است.\nاز دکمه «＋ قسط جدید» شروع کن.",17,Color.GRAY);
            e.setGravity(Gravity.CENTER);
            list.addView(e,new LinearLayout.LayoutParams(-1,dp(180)));
        }
    }

    void showMainMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add("قسط جدید");
        popup.getMenu().add("اطلاعات سازنده");
        popup.setOnMenuItemClickListener(item -> {
            if (item.getTitle().toString().equals("قسط جدید")) {
                showEditor(-1);
            } else {
                showCreatorInfo();
            }
            return true;
        });
        popup.show();
    }

    void showCreatorInfo() {
        TextView message = t("این برنامه توسط پوریا جلیلیان ساخته شده\n\nاکانت اینستاگرام: pouryajln", 15, TEXT);
        message.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        message.setPadding(dp(8), dp(4), dp(8), dp(4));
        new AlertDialog.Builder(this)
                .setTitle("اطلاعات سازنده")
                .setView(message)
                .setPositiveButton("باشه", null)
                .show();
    }

    void showEditor(int index) {
        final boolean edit=index>=0;
        Installment old=edit?items.get(index):null;

        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        box.setPadding(dp(4),dp(2),dp(4),0);

        TextView hint=t(edit ? "اطلاعات قسط را ویرایش کنید" : "اطلاعات قسط جدید را وارد کنید", 12, SECONDARY);
        hint.setGravity(Gravity.RIGHT);
        hint.setPadding(dp(2),0,dp(2),dp(5));
        box.addView(hint,new LinearLayout.LayoutParams(-1,dp(28)));

        TextView nameLabel=t("نام قسط",11,SECONDARY);
        nameLabel.setPadding(dp(2),0,0,0);
        box.addView(nameLabel,new LinearLayout.LayoutParams(-1,dp(18)));

        EditText name=new EditText(this);
        name.setHint("مثلاً: قسط بانک یا وام");
        name.setText(edit?old.name:"");
        name.setTextSize(14);
        name.setSingleLine(true);
        name.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        name.setPadding(dp(8),0,dp(8),0);
        name.setBackground(round(Color.rgb(247,249,252),dp(9)));
        box.addView(name,new LinearLayout.LayoutParams(-1,dp(42)));

        TextView amountLabel=t("مبلغ قسط (تومان)",11,SECONDARY);
        amountLabel.setPadding(dp(2),dp(7),0,0);
        box.addView(amountLabel,new LinearLayout.LayoutParams(-1,dp(25)));

        EditText amount=new EditText(this);
        amount.setHint("مثلاً: 4,000,000");
        amount.setSingleLine(true);
        amount.setInputType(InputType.TYPE_CLASS_NUMBER);
        amount.setText(edit?formatPlainAmount(old.amount):"");
        amount.setTextSize(14);
        amount.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        amount.setPadding(dp(8),0,dp(8),0);
        amount.setBackground(round(Color.rgb(247,249,252),dp(9)));
        box.addView(amount,new LinearLayout.LayoutParams(-1,dp(42)));

        TextView dayLabel=t("روز سررسید",11,SECONDARY);
        dayLabel.setPadding(dp(2),dp(7),0,0);
        box.addView(dayLabel,new LinearLayout.LayoutParams(-1,dp(25)));

        EditText day=new EditText(this);
        day.setHint("۱ تا ۳۱");
        day.setSingleLine(true);
        day.setInputType(InputType.TYPE_CLASS_NUMBER);
        day.setText(edit?String.valueOf(old.day):"");
        day.setTextSize(14);
        day.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        day.setPadding(dp(8),0,dp(8),0);
        day.setBackground(round(Color.rgb(247,249,252),dp(9)));
        box.addView(day,new LinearLayout.LayoutParams(-1,dp(42)));

        amount.addTextChangedListener(new TextWatcher() {
            boolean busy;
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){}
            public void afterTextChanged(Editable e){
                if(busy) return;
                String raw=e.toString().replace(",","").replace("٬","").trim();
                if(raw.isEmpty()) return;
                try{
                    long v=Long.parseLong(raw);
                    String f=String.format(Locale.US,"%,d",v);
                    if(!f.equals(e.toString())){
                        busy=true;
                        amount.setText(f);
                        amount.setSelection(f.length());
                        busy=false;
                    }
                }catch(Exception ignored){}
            }
        });

        AlertDialog d=new AlertDialog.Builder(this)
                .setTitle(edit?"ویرایش قسط":"قسط جدید")
                .setView(box)
                .setNegativeButton("انصراف",null)
                .setPositiveButton(edit?"ذخیره":"افزودن",null)
                .create();

        d.setOnShowListener(v->{
            d.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(BLUE);
            d.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(SECONDARY);
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(q->{
                String n=name.getText().toString().trim();
                String a=amount.getText().toString().replace(",","").replace("٬","").trim();
                int dy;
                try { dy=Integer.parseInt(day.getText().toString().trim()); }
                catch(Exception e) { dy=0; }

                if(n.isEmpty()){name.setError("نام قسط را وارد کن");return;}
                if(dy<1||dy>31){day.setError("روز باید بین ۱ تا ۳۱ باشد");return;}

                if(edit){old.name=n;old.amount=a;old.day=dy;}
                else items.add(new Installment(UUID.randomUUID().toString(),n,a,dy));

                saveData();
                render();
                scheduleAll();
                d.dismiss();
            });
        });
        d.show();

        Window w=d.getWindow();
        if(w!=null){
            w.setLayout(Math.min(dp(360), getResources().getDisplayMetrics().widthPixels-dp(32)), WindowManager.LayoutParams.WRAP_CONTENT);
        }
    }

    String formatPlainAmount(String a){
        if(a==null||a.trim().isEmpty()) return "";
        String raw=a.replace(",","").replace("٬","").trim();
        try{return String.format(Locale.US,"%,d",Long.parseLong(raw));}
        catch(Exception e){return a;}
    }

    void confirmDelete(Installment item) {
        new AlertDialog.Builder(this)
                .setTitle("حذف قسط")
                .setMessage("«"+item.name+"» حذف شود؟")
                .setNegativeButton("انصراف",null)
                .setPositiveButton("حذف",(d,w)->{
                    items.remove(item);
                    saveData();
                    render();
                    scheduleAll();
                }).show();
    }

    void scheduleAll() {
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        for(Installment x:items) {
            Intent in=new Intent(this,ReminderReceiver.class);
            in.putExtra("name",x.name);
            in.putExtra("day",x.day);
            in.putExtra("id",x.id);
            int req=1000+(x.id.hashCode()&0x3fffffff);
            PendingIntent pi=PendingIntent.getBroadcast(this,req,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi);

            int[] p=PersianDate.now();
            Calendar c=PersianDate.toGregorian(p[0],p[1],Math.min(x.day,31));
            c.set(Calendar.HOUR_OF_DAY,12);
            c.set(Calendar.MINUTE,0);
            c.set(Calendar.SECOND,0);
            c.set(Calendar.MILLISECOND,0);

            if(c.getTimeInMillis()<=System.currentTimeMillis()) {
                int nm=p[1]+1,ny=p[0];
                if(nm==13){nm=1;ny++;}
                c=PersianDate.toGregorian(ny,nm,Math.min(x.day,31));
                c.set(Calendar.HOUR_OF_DAY,12);
                c.set(Calendar.MINUTE,0);
                c.set(Calendar.SECOND,0);
                c.set(Calendar.MILLISECOND,0);
            }

            try {
                if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms())
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);
                else
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);
            } catch(SecurityException e) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);
            }
        }
    }
}
