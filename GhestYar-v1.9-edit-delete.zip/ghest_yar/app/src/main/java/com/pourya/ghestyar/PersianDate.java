package com.pourya.ghestyar;
import java.util.Calendar;
public class PersianDate {
 public static int[] now(){ return toJalali(Calendar.getInstance()); }
 public static int[] toJalali(Calendar c){ int gy=c.get(Calendar.YEAR),gm=c.get(Calendar.MONTH)+1,gd=c.get(Calendar.DAY_OF_MONTH); int[] gdm={0,31,28,31,30,31,30,31,31,30,31,30,31}; int gy2=gm>2?gy+1:gy; int days=355666+365*gy+((gy2+3)/4)-((gy2+99)/100)+((gy2+399)/400)+gd; for(int i=1;i<gm;i++)days+=gdm[i]; if(gm>2 && ((gy%4==0&&gy%100!=0)||gy%400==0))days++; int jy=-1595+33*(days/12053); days%=12053; jy+=4*(days/1461); days%=1461; if(days>365){jy+=(days-1)/365;days=(days-1)%365;} int jm=days<186?1+days/31:7+(days-186)/30; int jd=1+(days<186?days%31:(days-186)%30); return new int[]{jy,jm,jd}; }
 public static Calendar toGregorian(int jy,int jm,int jd){ int gy=jy+621; int[] r=jalaliToGregorian(jy,jm,jd); Calendar c=Calendar.getInstance(); c.set(r[0],r[1]-1,r[2],12,0,0);c.set(Calendar.MILLISECOND,0);return c; }
 private static int[] jalaliToGregorian(int jy,int jm,int jd){int jy2=jy+1595;int days=-355668+365*jy2+(jy2/33)*8+((jy2%33+3)/4)+jd+(jm<7?(jm-1)*31:(jm-7)*30+186);int gy=400*(days/146097);days%=146097;if(days>36524){gy+=100*((--days)/36524);days%=36524;if(days>=365)days++;}gy+=4*(days/1461);days%=1461;if(days>365){gy+=(days-1)/365;days=(days-1)%365;}int gd=days+1;int[] sal={0,31,28,31,30,31,30,31,31,30,31,30,31};int gm=1;while(gd>sal[gm]+(gm==2&&((gy%4==0&&gy%100!=0)||gy%400==0)?1:0)){gd-=sal[gm]+(gm==2&&((gy%4==0&&gy%100!=0)||gy%400==0)?1:0);gm++;}return new int[]{gy,gm,gd};}
}
