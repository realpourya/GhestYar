package com.pourya.ghestyar;
import android.app.*;import android.content.*;import android.media.AudioAttributes;import android.net.Uri;import android.os.*;
public class ReminderReceiver extends BroadcastReceiver{
 public void onReceive(Context c,Intent i){String name=i.getStringExtra("name");String ch="ghest_reminders_v2";NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(Build.VERSION.SDK_INT>=26){Uri sound=android.provider.Settings.System.DEFAULT_NOTIFICATION_URI;AudioAttributes aa=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();NotificationChannel nc=new NotificationChannel(ch,"یادآوری اقساط",NotificationManager.IMPORTANCE_HIGH);nc.setDescription("صدای یادآوری سررسید اقساط");nc.setSound(sound,aa);nc.enableVibration(true);nm.createNotificationChannel(nc);}
  Uri sound=android.provider.Settings.System.DEFAULT_NOTIFICATION_URI;Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ch):new Notification.Builder(c).setSound(sound);b.setSmallIcon(com.pourya.ghestyar.R.drawable.ic_launcher).setContentTitle("یادآوری قسط").setContentText(name+" — امروز موعد پرداخت است").setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH).setSound(sound).setDefaults(Notification.DEFAULT_VIBRATE);nm.notify((int)(System.currentTimeMillis()%1000000000),b.build());
 }
}
