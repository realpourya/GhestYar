package com.pourya.ghestyar;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.*;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String name = i.getStringExtra("name");
        boolean dayBefore = i.getBooleanExtra("dayBefore", false);

        // AlarmManager alarms are one-shot, but an older build may have left
        // duplicate alarms behind. Mark each calendar occurrence as delivered
        // so the same reminder can never notify more than once.
        int dueYear = i.getIntExtra("dueYear", 0);
        int dueMonth = i.getIntExtra("dueMonth", 0);
        int dueDay = i.getIntExtra("dueDay", 0);
        String id = i.getStringExtra("id");
        if (id == null) id = "unknown";
        String occurrence = id + "_" + dueYear + "_" + dueMonth + "_" + dueDay + "_" + (dayBefore ? "before" : "due");
        android.content.SharedPreferences sent = c.getSharedPreferences("reminder_sent", Context.MODE_PRIVATE);
        String sentKey = "sent_" + occurrence;
        if (sent.getBoolean(sentKey, false)) return;
        sent.edit().putBoolean(sentKey, true).apply();

        String ch = "ghest_reminders_v2";
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);

        Uri sound = android.provider.Settings.System.DEFAULT_NOTIFICATION_URI;
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel nc = new NotificationChannel(ch, "یادآوری اقساط", NotificationManager.IMPORTANCE_HIGH);
            nc.setDescription("صدای یادآوری سررسید اقساط");
            nc.setSound(sound, aa);
            nc.enableVibration(true);
            nm.createNotificationChannel(nc);
        }

        String text = dayBefore
                ? "پولاتو جمع کن فردا موعد پرداخت قسطه 🙂"
                : name + " — امروز موعد پرداخت است";

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, ch)
                : new Notification.Builder(c).setSound(sound);

        b.setSmallIcon(com.pourya.ghestyar.R.drawable.ic_launcher)
                .setContentTitle("یادآوری قسط")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setPriority(Notification.PRIORITY_HIGH)
                .setSound(sound)
                .setDefaults(Notification.DEFAULT_VIBRATE);

        nm.notify((int)(System.currentTimeMillis() % 1000000000), b.build());
    }
}
