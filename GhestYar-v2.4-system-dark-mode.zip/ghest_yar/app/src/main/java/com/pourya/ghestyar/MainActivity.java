package com.pourya.ghestyar;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.animation.ObjectAnimator;
import android.view.animation.DecelerateInterpolator;
import android.graphics.Insets;
import android.widget.*;
import java.util.*;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

public class MainActivity extends Activity {
    LinearLayout list, root;
    TextView summary, newInstallmentFab, moonIcon;
    LinearLayout summaryBox;
    android.content.SharedPreferences sp;
    ArrayList<Installment> items = new ArrayList<>();
    boolean showingInstallments = false;

    final int BLUE = Color.rgb(21,101,192);
    final int BG = Color.rgb(244,247,251);
    final int DARK_BG = Color.rgb(18,22,29);
    final int TEXT = Color.rgb(23,32,51);
    final int SECONDARY = Color.rgb(101,112,132);
    final String PREF = "installments";

    String[] defaultNames = {"قسط بانک سپه","قسط دیجی‌کالا - اسنپ‌پی","اجاره خانه","قسط وام ۱۰۰ تومنی محمد","قسط مؤسسه ملل","بیمه ماشین","قسط بانک مهر","قسط بانک مهر","قسط بانک مهر","وام خانگی"};
    int[] defaultDays = {3,5,8,11,13,16,16,17,18,30};

    boolean isSystemDarkMode() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    int currentBackgroundColor() {
        return isSystemDarkMode() ? DARK_BG : BG;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sp = getSharedPreferences(PREF, 0);
        load();
        build();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        scheduleAll();
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (root != null) {
            int bg = currentBackgroundColor();
            root.setBackgroundColor(bg);
            getWindow().setNavigationBarColor(bg);
            if (moonIcon != null) moonIcon.setTextColor(isSystemDarkMode() ? Color.rgb(255,210,90) : BLUE);
            if (Build.VERSION.SDK_INT >= 26) {
                getWindow().getDecorView().setSystemUiVisibility(isSystemDarkMode() ? 0 : View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            }
        }
    }

    static class Installment {
        String id, name, amount;
        int day;
        Installment(String i, String n, String a, int d) { id=i; name=n; amount=a; day=d; }
    }

    String paidKey(Installment x) {
        int[] p = PersianDate.now();
        return "paid_" + x.id + "_" + p[0] + "_" + p[1];
    }

    void load() {
        items.clear();
        int count = sp.getInt("count", -1);
        if (count < 0) {
            for (int i=0; i<defaultNames.length; i++)
                items.add(new Installment(UUID.randomUUID().toString(), defaultNames[i], "", defaultDays[i]));
            saveData();
            return;
        }
        for (int i=0; i<count; i++) {
            String id = sp.getString("id_"+i, UUID.randomUUID().toString());
            String n = sp.getString("name_"+i, "");
            String a = sp.getString("amount_"+i, "");
            int d = sp.getInt("day_"+i, 1);
            items.add(new Installment(id,n,a,d));
        }
    }

    // IMPORTANT: Do not clear SharedPreferences here.
    // Payment flags are intentionally preserved when the list is edited.
    void saveData() {
        android.content.SharedPreferences.Editor e = sp.edit();
        e.putInt("count", items.size());
        for (int i=0; i<items.size(); i++) {
            Installment x=items.get(i);
            e.putString("id_"+i,x.id);
            e.putString("name_"+i,x.name);
            e.putString("amount_"+i,x.amount);
            e.putInt("day_"+i,x.day);
        }
        // Remove only stale installment slots; never remove paid_* keys.
        int oldCount = sp.getInt("count", items.size());
        for (int i=items.size(); i<oldCount; i++) {
            e.remove("id_"+i).remove("name_"+i).remove("amount_"+i).remove("day_"+i);
        }
        e.apply();
    }

    int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(16), dp(10), dp(16), dp(8));
        // Keep the header safely below the status bar on modern Android versions.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0;
            int bottom = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(dp(16), dp(10) + top, dp(16), dp(8) + bottom);
            return insets;
        });
        root.setBackgroundColor(currentBackgroundColor());
        getWindow().setNavigationBarColor(currentBackgroundColor());
        if (Build.VERSION.SDK_INT >= 26) {
            getWindow().getDecorView().setSystemUiVisibility(isSystemDarkMode() ? 0 : View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        head.setPadding(0,dp(4),0,dp(6));

        TextView menuBtn = t("☰", 29, BLUE);
        menuBtn.setGravity(Gravity.CENTER);
        menuBtn.setContentDescription("منوی برنامه");
        menuBtn.setBackground(round(Color.WHITE, dp(12)));
        menuBtn.setElevation(dp(1));
        menuBtn.setOnClickListener(v -> showMainMenu(menuBtn));

        LinearLayout titleArea = new LinearLayout(this);
        titleArea.setOrientation(LinearLayout.HORIZONTAL);
        titleArea.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        titleArea.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        TextView title = t("قسط‌یار", 24, BLUE);
        title.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        title.setTypeface(null, android.graphics.Typeface.BOLD);

        moonIcon = t("☾", 27, isSystemDarkMode() ? Color.rgb(255,210,90) : BLUE);
        moonIcon.setGravity(Gravity.CENTER);
        moonIcon.setContentDescription("حالت شب گوشی");
        moonIcon.setPadding(dp(6), 0, dp(2), 0);

        titleArea.addView(title, new LinearLayout.LayoutParams(-2, dp(52)));
        titleArea.addView(moonIcon, new LinearLayout.LayoutParams(dp(40), dp(52)));

        head.addView(menuBtn, new LinearLayout.LayoutParams(dp(54), dp(52)));
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, dp(52), 1);
        titleLp.setMargins(dp(8),0,0,0);
        head.addView(titleArea, titleLp);
        root.addView(head);

        summaryBox = new LinearLayout(this);
        summaryBox.setOrientation(LinearLayout.VERTICAL);
        summaryBox.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        summaryBox.setPadding(dp(14), dp(8), dp(14), dp(10));
        summaryBox.setBackground(round(Color.WHITE, dp(16)));
        summaryBox.setElevation(dp(1));
        root.addView(summaryBox, new LinearLayout.LayoutParams(-1, dp(96)));
        summary = t("", 13, SECONDARY);
        summary.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        summaryBox.addView(summary, new LinearLayout.LayoutParams(-1, dp(34)));

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        FrameLayout content = new FrameLayout(this);
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.setClipToPadding(false);
        list.setPadding(0, 0, 0, dp(76));
        sv.addView(list);
        content.addView(sv, new FrameLayout.LayoutParams(-1, -1));

        // «قسط جدید» is now a floating action button inside the installments screen.
        newInstallmentFab = t("＋  قسط جدید", 14, Color.WHITE);
        newInstallmentFab.setGravity(Gravity.CENTER);
        newInstallmentFab.setTypeface(null, android.graphics.Typeface.BOLD);
        newInstallmentFab.setBackground(round(BLUE, dp(18)));
        newInstallmentFab.setElevation(dp(7));
        newInstallmentFab.setPadding(dp(14), 0, dp(14), 0);
        newInstallmentFab.setOnClickListener(v -> showEditor(-1));
        FrameLayout.LayoutParams fabLp = new FrameLayout.LayoutParams(-2, dp(48), Gravity.BOTTOM | Gravity.END);
        fabLp.setMargins(dp(12), dp(12), dp(12), dp(12));
        content.addView(newInstallmentFab, fabLp);

        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
        renderHome();
    }

    TextView t(String s, int size, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return v;
    }

    GradientDrawable round(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    String dayText(int d) {
        String[] w={"","اول","دوم","سوم","چهارم","پنجم","ششم","هفتم","هشتم","نهم","دهم","یازدهم","دوازدهم","سیزدهم","چهاردهم","پانزدهم","شانزدهم","هفدهم","هجدهم","نوزدهم","بیستم","بیست‌ویکم","بیست‌ودوم","بیست‌وسوم","بیست‌وچهارم","بیست‌وپنجم","بیست‌وششم","بیست‌وهفتم","بیست‌وهشتم","بیست‌ونهم","سی‌ام","سی‌ویکم"};
        return d>=1&&d<=31 ? w[d] : String.valueOf(d);
    }

    String fmtAmount(String a) {
        if (a == null || a.trim().isEmpty()) return "";
        String raw = a.replace(",", "").replace("٬", "").trim();
        try {
            long value = Long.parseLong(raw);
            DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance(Locale.US);
            DecimalFormat formatter = new DecimalFormat("#,##0", symbols);
            return "  •  " + formatter.format(value) + " تومان";
        } catch (Exception e) {
            return "  •  " + a.trim() + " تومان";
        }
    }

    void render() {
        if (showingInstallments) renderInstallments();
        else renderHome();
    }

    void renderHome() {
        if (newInstallmentFab != null) newInstallmentFab.setVisibility(View.GONE);
        list.removeAllViews();
        summary.setText("");

        LinearLayout folder = new LinearLayout(this);
        folder.setOrientation(LinearLayout.HORIZONTAL);
        folder.setGravity(Gravity.CENTER_VERTICAL);
        folder.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        folder.setPadding(dp(16), dp(10), dp(16), dp(10));
        folder.setBackground(round(Color.WHITE, dp(16)));
        folder.setElevation(dp(1));

        TextView icon = t("▣", 30, BLUE);
        icon.setGravity(Gravity.CENTER);
        TextView title = t("قسط های من", 19, TEXT);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView count = t(items.size() + " قسط", 12, SECONDARY);
        count.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);

        LinearLayout folderText = new LinearLayout(this);
        folderText.setOrientation(LinearLayout.VERTICAL);
        folderText.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        folderText.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        folderText.addView(title, new LinearLayout.LayoutParams(-1, dp(30)));
        folderText.addView(count, new LinearLayout.LayoutParams(-1, dp(22)));

        folder.addView(icon, new LinearLayout.LayoutParams(dp(52), dp(58)));
        folder.addView(folderText, new LinearLayout.LayoutParams(0, dp(58), 1));
        folder.setOnClickListener(v -> { showingInstallments = true; renderInstallments(); });

        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(82));
        fp.setMargins(0, dp(8), 0, dp(8));
        list.addView(folder, fp);

        TextView hint = t("برای مشاهده اقساط، وارد «قسط های من» شوید", 12, SECONDARY);
        hint.setGravity(Gravity.CENTER);
        list.addView(hint, new LinearLayout.LayoutParams(-1, dp(40)));
    }

    void renderInstallments() {
        if (newInstallmentFab != null) newInstallmentFab.setVisibility(View.VISIBLE);
        list.removeAllViews();
        int[] p = PersianDate.now();
        int paid = 0;
        for (Installment x : items) if (sp.getBoolean(paidKey(x), false)) paid++;
        updateSummaryHeader(p[0], p[1], paid, items.size());

        TextView back = t("‹  قسط های من", 14, BLUE);
        back.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        back.setPadding(dp(4), 0, dp(4), 0);
        back.setOnClickListener(v -> { showingInstallments = false; renderHome(); });
        list.addView(back, new LinearLayout.LayoutParams(-1, dp(36)));

        LinearLayout columns = new LinearLayout(this);
        columns.setOrientation(LinearLayout.HORIZONTAL);
        columns.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        columns.setGravity(Gravity.TOP);

        int unpaidCount = 0;
        int paidCount = 0;
        for (Installment x : items) {
            if (sp.getBoolean(paidKey(x), false)) paidCount++;
            else unpaidCount++;
        }

        LinearLayout unpaidCol = makeColumn("پرداخت نشده", Color.rgb(255, 220, 220), Color.rgb(190, 45, 55), unpaidCount);
        LinearLayout paidCol = makeColumn("پرداخت شده", Color.rgb(211, 241, 220), Color.rgb(35, 135, 75), paidCount);

        ArrayList<Installment> sorted = new ArrayList<>(items);
        Collections.sort(sorted, (a,b) -> Integer.compare(a.day,b.day));
        for (Installment x : sorted) {
            if (sp.getBoolean(paidKey(x), false)) addInstallmentCard(paidCol, x, true);
            else addInstallmentCard(unpaidCol, x, false);
        }

        columns.addView(unpaidCol, new LinearLayout.LayoutParams(0, -2, 1));
        columns.addView(paidCol, new LinearLayout.LayoutParams(0, -2, 1));
        list.addView(columns, new LinearLayout.LayoutParams(-1, -2));

        if (items.isEmpty()) {
            TextView e=t("هنوز قسطی ثبت نشده است.\nاز دکمه «＋ قسط جدید» استفاده کنید.",15,Color.GRAY);
            e.setGravity(Gravity.CENTER);
            list.addView(e,new LinearLayout.LayoutParams(-1,dp(160)));
        }
    }


    String persianMonthName(int month) {
        String[] names = {"", "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"};
        return month >= 1 && month <= 12 ? names[month] : "";
    }

    String persianNumber(int n) {
        return String.valueOf(n).replace('0','۰').replace('1','۱').replace('2','۲').replace('3','۳').replace('4','۴').replace('5','۵').replace('6','۶').replace('7','۷').replace('8','۸').replace('9','۹');
    }

    void updateSummaryHeader(int year, int month, int paid, int total) {
        if (summaryBox == null) return;
        summaryBox.removeAllViews();

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView monthTitle = t("اقساط " + persianMonthName(month) + " ماه", 17, TEXT);
        monthTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        monthTitle.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        top.addView(monthTitle, new LinearLayout.LayoutParams(0, dp(34), 1));

        TextView progressText = t(persianNumber(paid) + " از " + persianNumber(total) + " قسط", 12, BLUE);
        progressText.setGravity(Gravity.CENTER);
        progressText.setTypeface(null, android.graphics.Typeface.BOLD);
        progressText.setBackground(round(Color.rgb(232, 242, 255), dp(18)));
        progressText.setPadding(dp(10), 0, dp(10), 0);
        top.addView(progressText, new LinearLayout.LayoutParams(-2, dp(30)));
        summaryBox.addView(top, new LinearLayout.LayoutParams(-1, dp(36)));

        LinearLayout track = new LinearLayout(this);
        track.setOrientation(LinearLayout.HORIZONTAL);
        track.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        track.setGravity(Gravity.CENTER_VERTICAL);
        track.setPadding(0, dp(5), 0, 0);

        View progress = new View(this);
        progress.setBackground(round(BLUE, dp(7)));
        View remaining = new View(this);
        remaining.setBackground(round(Color.rgb(225,230,237), dp(7)));
        int safeTotal = Math.max(total, 1);
        int targetProgress = Math.max(0, Math.min(100, Math.round((paid * 100f) / safeTotal)));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, dp(9), targetProgress);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, dp(9), 100 - targetProgress);
        track.addView(progress, pp);
        track.addView(remaining, rp);
        summaryBox.addView(track, new LinearLayout.LayoutParams(-1, dp(16)));

        progress.setScaleX(0f);
        progress.setPivotX(0f);
        ObjectAnimator anim = ObjectAnimator.ofFloat(progress, View.SCALE_X, 0f, 1f);
        anim.setDuration(550);
        anim.setInterpolator(new DecelerateInterpolator());
        progress.post(anim::start);
    }

    LinearLayout makeColumn(String titleText, int headerBg, int headerText, int count) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        col.setPadding(dp(3), 0, dp(3), 0);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        header.setPadding(dp(10), 0, dp(8), 0);
        header.setBackground(round(headerBg, dp(13)));
        header.setElevation(dp(1));

        TextView badge = t(persianNumber(count), 13, Color.WHITE);
        badge.setGravity(Gravity.CENTER);
        badge.setTypeface(null, android.graphics.Typeface.BOLD);
        badge.setBackground(round(headerText, dp(20)));
        header.addView(badge, new LinearLayout.LayoutParams(dp(30), dp(30)));

        TextView h = t(titleText, 14, headerText);
        h.setGravity(Gravity.CENTER);
        h.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, -1, 1);
        titleLp.setMargins(dp(4), 0, dp(4), 0);
        header.addView(h, titleLp);

        col.addView(header, new LinearLayout.LayoutParams(-1, dp(42)));
        return col;
    }

    void addInstallmentCard(LinearLayout col, Installment item, boolean isPaid) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setPadding(dp(7), dp(6), dp(7), dp(6));
        int bg = isPaid ? Color.rgb(232,246,235) : Color.rgb(255,238,238);
        card.setBackground(round(bg, dp(12)));
        card.setElevation(dp(1));

        TextView name = t(item.name, 13, TEXT);
        name.setGravity(Gravity.CENTER);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);

        TextView info = t("روز " + dayText(item.day) + fmtAmount(item.amount), 10, SECONDARY);
        info.setGravity(Gravity.CENTER);
        info.setSingleLine(true);
        info.setEllipsize(android.text.TextUtils.TruncateAt.END);

        // Tapping the installment card toggles its payment status.
        // The checkbox is intentionally removed to keep the card clean and easier to use.
        card.addView(name, new LinearLayout.LayoutParams(-1, dp(30)));
        card.addView(info, new LinearLayout.LayoutParams(-1, dp(28)));
        card.setOnClickListener(v -> {
            boolean newPaid = !sp.getBoolean(paidKey(item), false);
            sp.edit().putBoolean(paidKey(item), newPaid).apply();
            if (newPaid) {
                Toast.makeText(MainActivity.this, "خدا قوت پهلوان ادامه بده 🙂", Toast.LENGTH_LONG).show();
            }
            renderInstallments();
        });
        card.setOnLongClickListener(v -> { showInstallmentActions(item); return true; });

        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(68));
        cp.setMargins(0, dp(5), 0, 0);
        col.addView(card, cp);
    }

    void showMainMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add("اطلاعات سازنده");
        popup.setOnMenuItemClickListener(item -> {
            showCreatorInfo();
            return true;
        });
        popup.show();
    }

    void showCreatorInfo() {
        TextView message = t("این برنامه توسط پوریا جلیلیان ساخته شده\n\nاکانت اینستاگرام: pouryajln", 15, TEXT);
        message.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        message.setPadding(dp(8), dp(4), dp(8), dp(4));
        new AlertDialog.Builder(this)
                .setTitle("اطلاعات سازنده")
                .setView(message)
                .setPositiveButton("باشه", null)
                .show();
    }

    void showEditor(int index) {
        final boolean edit=index>=0;
        Installment old=edit?items.get(index):null;

        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        box.setPadding(dp(4),dp(2),dp(4),0);

        TextView hint=t(edit ? "اطلاعات قسط را ویرایش کنید" : "اطلاعات قسط جدید را وارد کنید", 12, SECONDARY);
        hint.setGravity(Gravity.RIGHT);
        hint.setPadding(dp(2),0,dp(2),dp(5));
        box.addView(hint,new LinearLayout.LayoutParams(-1,dp(28)));

        TextView nameLabel=t("نام قسط",11,SECONDARY);
        nameLabel.setPadding(dp(2),0,0,0);
        box.addView(nameLabel,new LinearLayout.LayoutParams(-1,dp(18)));

        EditText name=new EditText(this);
        name.setHint("مثلاً: قسط بانک یا وام");
        name.setText(edit?old.name:"");
        name.setTextSize(14);
        name.setSingleLine(true);
        name.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        name.setPadding(dp(8),0,dp(8),0);
        name.setBackground(round(Color.rgb(247,249,252),dp(9)));
        box.addView(name,new LinearLayout.LayoutParams(-1,dp(42)));

        TextView amountLabel=t("مبلغ قسط (تومان)",11,SECONDARY);
        amountLabel.setPadding(dp(2),dp(7),0,0);
        box.addView(amountLabel,new LinearLayout.LayoutParams(-1,dp(25)));

        EditText amount=new EditText(this);
        amount.setHint("مثلاً: 4,000,000");
        amount.setSingleLine(true);
        amount.setInputType(InputType.TYPE_CLASS_NUMBER);
        amount.setText(edit?formatPlainAmount(old.amount):"");
        amount.setTextSize(14);
        amount.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        amount.setPadding(dp(8),0,dp(8),0);
        amount.setBackground(round(Color.rgb(247,249,252),dp(9)));
        box.addView(amount,new LinearLayout.LayoutParams(-1,dp(42)));

        TextView dayLabel=t("روز سررسید",11,SECONDARY);
        dayLabel.setPadding(dp(2),dp(7),0,0);
        box.addView(dayLabel,new LinearLayout.LayoutParams(-1,dp(25)));

        EditText day=new EditText(this);
        day.setHint("۱ تا ۳۱");
        day.setSingleLine(true);
        day.setInputType(InputType.TYPE_CLASS_NUMBER);
        day.setText(edit?String.valueOf(old.day):"");
        day.setTextSize(14);
        day.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        day.setPadding(dp(8),0,dp(8),0);
        day.setBackground(round(Color.rgb(247,249,252),dp(9)));
        box.addView(day,new LinearLayout.LayoutParams(-1,dp(42)));

        amount.addTextChangedListener(new TextWatcher() {
            boolean busy;
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){}
            public void afterTextChanged(Editable e){
                if(busy) return;
                String raw=e.toString().replace(",","").replace("٬","").trim();
                if(raw.isEmpty()) return;
                try{
                    long v=Long.parseLong(raw);
                    String f=String.format(Locale.US,"%,d",v);
                    if(!f.equals(e.toString())){
                        busy=true;
                        amount.setText(f);
                        amount.setSelection(f.length());
                        busy=false;
                    }
                }catch(Exception ignored){}
            }
        });

        AlertDialog d=new AlertDialog.Builder(this)
                .setTitle(edit?"ویرایش قسط":"قسط جدید")
                .setView(box)
                .setNegativeButton("انصراف",null)
                .setPositiveButton(edit?"ذخیره":"افزودن",null)
                .create();

        d.setOnShowListener(v->{
            d.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(BLUE);
            d.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(SECONDARY);
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(q->{
                String n=name.getText().toString().trim();
                String a=amount.getText().toString().replace(",","").replace("٬","").trim();
                int dy;
                try { dy=Integer.parseInt(day.getText().toString().trim()); }
                catch(Exception e) { dy=0; }

                if(n.isEmpty()){name.setError("نام قسط را وارد کن");return;}
                if(dy<1||dy>31){day.setError("روز باید بین ۱ تا ۳۱ باشد");return;}

                if(edit){old.name=n;old.amount=a;old.day=dy;}
                else items.add(new Installment(UUID.randomUUID().toString(),n,a,dy));

                saveData();
                render();
                scheduleAll();
                d.dismiss();
            });
        });
        d.show();

        Window w=d.getWindow();
        if(w!=null){
            w.setLayout(Math.min(dp(360), getResources().getDisplayMetrics().widthPixels-dp(32)), WindowManager.LayoutParams.WRAP_CONTENT);
        }
    }

    String formatPlainAmount(String a){
        if(a==null||a.trim().isEmpty()) return "";
        String raw=a.replace(",","").replace("٬","").trim();
        try{return String.format(Locale.US,"%,d",Long.parseLong(raw));}
        catch(Exception e){return a;}
    }

    void showInstallmentActions(Installment item) {
        String[] options = {"ویرایش", "حذف قسط"};

        new AlertDialog.Builder(this)
                .setTitle("مدیریت قسط")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        int index = items.indexOf(item);
                        if (index >= 0) showEditor(index);
                    } else {
                        confirmDelete(item);
                    }
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    void confirmDelete(Installment item) {
        new AlertDialog.Builder(this)
                .setTitle("حذف قسط")
                .setMessage("«"+item.name+"» حذف شود؟")
                .setNegativeButton("انصراف",null)
                .setPositiveButton("بله، حذف شود",(d,w)->{
                    cancelReminder(item);
                    items.remove(item);
                    // Remove the current payment-status flag for this installment.
                    sp.edit().remove(paidKey(item)).apply();
                    saveData();
                    render();
                    scheduleAll();
                })
                .show();
    }

    int reminderRequestCode(Installment x, boolean dayBefore) {
        int base = 1000 + (x.id.hashCode() & 0x3fffffff);
        return base * 2 + (dayBefore ? 1 : 0);
    }

    void cancelReminder(Installment x) {
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        for (int n=0; n<2; n++) {
            boolean dayBefore = n == 1;
            Intent in=new Intent(this,ReminderReceiver.class);
            in.putExtra("name",x.name);
            in.putExtra("day",x.day);
            in.putExtra("id",x.id);
            in.putExtra("dayBefore",dayBefore);
            int req=reminderRequestCode(x,dayBefore);
            PendingIntent pi=PendingIntent.getBroadcast(this,req,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi);
            pi.cancel();
        }
    }

    void scheduleAll() {
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        long now = System.currentTimeMillis();
        for(Installment x:items) {
            cancelReminder(x);

            int[] p=PersianDate.now();
            int year=p[0], month=p[1];
            Calendar due=PersianDate.toGregorian(year,month,Math.min(x.day,31));
            due.set(Calendar.HOUR_OF_DAY,12);
            due.set(Calendar.MINUTE,0);
            due.set(Calendar.SECOND,0);
            due.set(Calendar.MILLISECOND,0);

            if(due.getTimeInMillis()<=now) {
                month++;
                if(month==13){month=1;year++;}
                due=PersianDate.toGregorian(year,month,Math.min(x.day,31));
                due.set(Calendar.HOUR_OF_DAY,12);
                due.set(Calendar.MINUTE,0);
                due.set(Calendar.SECOND,0);
                due.set(Calendar.MILLISECOND,0);
            }

            // Only schedule a reminder when its exact 12:00 time is still in the future.
            // This prevents an overdue "one day before" alarm from firing immediately
            // every time the app is opened or an installment is edited.
            if (due.getTimeInMillis() > now) {
                scheduleReminder(am,x,due,false,year,month,x.day);

                Calendar dayBefore=(Calendar)due.clone();
                dayBefore.add(Calendar.DAY_OF_MONTH,-1);
                dayBefore.set(Calendar.HOUR_OF_DAY,12);
                dayBefore.set(Calendar.MINUTE,0);
                dayBefore.set(Calendar.SECOND,0);
                dayBefore.set(Calendar.MILLISECOND,0);
                if (dayBefore.getTimeInMillis() > now) {
                    scheduleReminder(am,x,dayBefore,true,year,month,x.day);
                }
            }
        }
    }

    void scheduleReminder(AlarmManager am, Installment x, Calendar when, boolean dayBefore,
                          int dueYear, int dueMonth, int dueDay) {
        Intent in=new Intent(this,ReminderReceiver.class);
        in.putExtra("name",x.name);
        in.putExtra("day",x.day);
        in.putExtra("id",x.id);
        in.putExtra("dayBefore",dayBefore);
        in.putExtra("dueYear",dueYear);
        in.putExtra("dueMonth",dueMonth);
        in.putExtra("dueDay",dueDay);
        int req=reminderRequestCode(x,dayBefore);
        PendingIntent pi=PendingIntent.getBroadcast(this,req,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        try {
            if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms())
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when.getTimeInMillis(),pi);
            else
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when.getTimeInMillis(),pi);
        } catch(SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when.getTimeInMillis(),pi);
        }
    }

}
