package com.pourya.ghestyar;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.*;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String name = i.getStringExtra("name");
        String id = i.getStringExtra("id");
        int dueYear = i.getIntExtra("dueYear", 0);
        int dueMonth = i.getIntExtra("dueMonth", 0);
        int dueDay = i.getIntExtra("dueDay", 0);
        String paidKey = i.getStringExtra("paidKey");
        if (id == null || paidKey == null) return;

        android.content.SharedPreferences installments =
                c.getSharedPreferences("installments", Context.MODE_PRIVATE);
        // If the user paid after the due date but before this alert, stay quiet.
        if (installments.getBoolean(paidKey, false)) return;

        String occurrence = id + "_" + dueYear + "_" + dueMonth + "_" + dueDay;
        android.content.SharedPreferences sent =
                c.getSharedPreferences("reminder_sent", Context.MODE_PRIVATE);
        String sentKey = "overdue_" + occurrence;
        if (sent.getBoolean(sentKey, false)) return;
        sent.edit().putBoolean(sentKey, true).apply();

        String ch = "ghest_overdue_v1";
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        Uri sound = android.provider.Settings.System.DEFAULT_NOTIFICATION_URI;
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel nc = new NotificationChannel(ch, "یادآوری اقساط پرداخت‌نشده", NotificationManager.IMPORTANCE_HIGH);
            nc.setDescription("اعلان یک‌باره برای قسط پرداخت‌نشده، یک روز پس از سررسید");
            nc.setSound(sound, aa);
            nc.enableVibration(true);
            nm.createNotificationChannel(nc);
        }

        String text = (name == null ? "قسط" : name) + " هنوز پرداخت نشده است؛ موعد پرداخت آن گذشته است.";
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, ch)
                : new Notification.Builder(c).setSound(sound);

        b.setSmallIcon(com.pourya.ghestyar.R.drawable.ic_launcher)
                .setContentTitle("یادآوری قسط پرداخت‌نشده")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setPriority(Notification.PRIORITY_HIGH)
                .setSound(sound)
                .setDefaults(Notification.DEFAULT_VIBRATE);

        nm.notify(occurrence.hashCode(), b.build());
    }
}
