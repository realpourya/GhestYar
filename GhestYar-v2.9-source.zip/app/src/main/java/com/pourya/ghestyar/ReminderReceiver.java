package com.pourya.ghestyar;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.*;
import java.util.Calendar;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String id = i.getStringExtra("id");
        if (id == null) id = "unknown";
        String name = i.getStringExtra("name");
        int dueYear = i.getIntExtra("dueYear", 0);
        int dueMonth = i.getIntExtra("dueMonth", 0);
        int dueDay = i.getIntExtra("dueDay", 1);

        String paidKey = "paid_" + id + "_" + dueYear + "_" + dueMonth;
        SharedPreferences payments = c.getSharedPreferences("installments", Context.MODE_PRIVATE);
        boolean alreadyPaid = payments.getBoolean(paidKey, false);

        String occurrence = id + "_" + dueYear + "_" + dueMonth + "_" + dueDay + "_overdue";
        SharedPreferences sent = c.getSharedPreferences("reminder_sent", Context.MODE_PRIVATE);
        String sentKey = "sent_" + occurrence;

        if (!alreadyPaid && !sent.getBoolean(sentKey, false)) {
            sent.edit().putBoolean(sentKey, true).apply();

            String ch = "ghest_overdue_v1";
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            Uri sound = android.provider.Settings.System.DEFAULT_NOTIFICATION_URI;
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();

            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel nc = new NotificationChannel(ch, "اقساط عقب‌افتاده", NotificationManager.IMPORTANCE_HIGH);
                nc.setDescription("یادآوری اقساط پرداخت‌نشده پس از سررسید");
                nc.setSound(sound, aa);
                nc.enableVibration(true);
                nm.createNotificationChannel(nc);
            }

            String text = "قسط عقب افتاده داری ستون ☹️";
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(c, ch)
                    : new Notification.Builder(c).setSound(sound);

            b.setSmallIcon(com.pourya.ghestyar.R.drawable.ic_launcher)
                    .setContentTitle("یادآوری قسط")
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setAutoCancel(true)
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setSound(sound)
                    .setDefaults(Notification.DEFAULT_VIBRATE);
            nm.notify((id + "_" + dueYear + "_" + dueMonth).hashCode(), b.build());
        }

        // Schedule the next monthly overdue check even if this month's installment was paid.
        if (dueYear > 0 && dueMonth > 0) {
            int nextYear = dueYear;
            int nextMonth = dueMonth + 1;
            if (nextMonth == 13) { nextMonth = 1; nextYear++; }
            int monthLength;
            if (nextMonth <= 6) monthLength = 31;
            else if (nextMonth <= 11) monthLength = 30;
            else {
                Calendar thisYear = PersianDate.toGregorian(nextYear, 1, 1);
                Calendar followingYear = PersianDate.toGregorian(nextYear + 1, 1, 1);
                long days = (followingYear.getTimeInMillis() - thisYear.getTimeInMillis()) / 86400000L;
                monthLength = days >= 366 ? 30 : 29;
            }
            Calendar nextDue = PersianDate.toGregorian(nextYear, nextMonth, Math.min(dueDay, monthLength));
            nextDue.add(Calendar.DAY_OF_MONTH, 1);
            nextDue.set(Calendar.HOUR_OF_DAY, 12);
            nextDue.set(Calendar.MINUTE, 0);
            nextDue.set(Calendar.SECOND, 0);
            nextDue.set(Calendar.MILLISECOND, 0);

            Intent next = new Intent(c, ReminderReceiver.class);
            next.putExtra("id", id);
            next.putExtra("name", name);
            next.putExtra("day", dueDay);
            next.putExtra("overdue", true);
            next.putExtra("dueYear", nextYear);
            next.putExtra("dueMonth", nextMonth);
            next.putExtra("dueDay", dueDay);

            int requestCode = 1000 + (id.hashCode() & 0x3fffffff);
            requestCode = requestCode * 2 + 1;
            PendingIntent pi = PendingIntent.getBroadcast(c, requestCode, next,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            try {
                if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms())
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextDue.getTimeInMillis(), pi);
                else
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextDue.getTimeInMillis(), pi);
            } catch (SecurityException e) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextDue.getTimeInMillis(), pi);
            }
        }
    }
}
